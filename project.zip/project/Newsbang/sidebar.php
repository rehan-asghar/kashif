  <div class="widgets">
                        <div class="popular">
                            <h4><strong> Popular Posts </strong></h4>
                            <hr>
              <?php

popular();


               ?>
                      </div>      

                    </div><!--widgets close-->
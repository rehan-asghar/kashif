<?php
session_start();
unset($_SESSION['newsbang']);
header("location:index.php")
?>
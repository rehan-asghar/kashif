<?php

include('headerr.html'); 
?>
   <style type="text/css">
     
.caption{


  background-color: #F5F6F7;
  font-size: 17px;

}
.col-sm-3{
 background-color: #F5F6F7;
  font-size: 17px;


}



   </style>

<div class="container  " style="background-color:white;">
<div class="row">
  <div class="col-sm-8">
    <br>
     <br>
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
     
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
      </ol>

      <div class="carousel-inner" role="listbox">
        <div class="item active">
          <img src="ik4.jp" alt="Image">
          <div class="carousel-caption">
        
          </div>  

        </div>
   

        <div class="item">
          <img src="ik4.jpg" alt="Image">
          <div class="carousel-caption">
            <h3>More Sell $</h3>
            <p>Lorem ipsum...</p>
          </div>      
        </div>
      </div>

      <!-- Left and right controls -->
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>
<h4 >
Trending
</h4>
 <div class="col-md-3" style="background-color: #F5F6F7;
  font-size: 17px;">
      <img src="ik.jpg" class="img-responsive" style="width:100%" alt="Image">
    <a href="#">So it is Judiciary that has constitutional duty of ehtesab. </a>
    </div>
     <div class="col-sm-3">
      <img src="ik.jpg" class="img-responsive" style="width:100%" alt="Image">
    <a href="#">So it is Judiciary that has constitutional duty of ehtesab. </a>
    </div>
     <div class="col-sm-3">
      <img src="ik.jpg" class="img-responsive" style="width:100%" alt="Image">
 <a href="#">So it is Judiciary that has constitutional duty of ehtesab. </a>
    </div>
      


<div class="section2  "  style="background-color:white; >
   
  <div class="container-fluid " >
      <div class="row">

        <div class="col-sm-12">
          <div class="page-header">
            <h1>Lates News</h1>
            
          </div>
        </div>
      </div>
      

      <div class="row margin-b-2">
        <div class="col-sm-4">
          <img class="img-responsive thumbnail" src="ik.jpg" alt="">
          <div class="caption">
            <h4><a href="#">Imran Khan on twitter</a></h4>
            <p>So it is Judiciary that has constitutional duty of ehtesab. NS trying to stir ppl into doing his ehtesab is also a violation of constitution & a call for mob justice. Undermining the judiciary and the Constitution shows NS has no legal defence ag the criminal charges against him.</p>
          </div>
        </div>
        <div class="col-sm-4">
          <img class="img-responsive thumbnail" src="ik1.jpg" alt="">
          <div class="caption">
            <h4><a href="#">Pakistan Election Commission issues warrant against Imran Khan</a></h4>
            <p>Pakistan Election Commission issues warrant against Imran KhanPakistan Election Commission issues warrant against Imran Khan</p>
          </div>
        </div>
        <div class="col-sm-4">
          <img class="img-responsive thumbnail" src="ik4.jpg" alt="">
          <div class="caption">
            <h4><a href="#">Dr Tahir-ul-Qadri's Interview with anchor Imran Khan on Express News</a></h4>
            <p>Dr Tahir-ul-Qadri's Interview with anchor Imran Khan on Express NewsDr Tahir-ul-Qadri's Interview with anchor Imran Khan on Express News.</p>
          </div>
        </div>
                
      </div>
      <!-- /.row -->

      <div class="row margin-b-2">
        <div class="col-sm-4">
          <img class="img-responsive thumbnail" src="ik4.jpg" alt="">
          <div class="caption">
            <h4><a href="#">Khan takes oath as lawmaker,</a></h4>
            <p>Khan takes oath as lawmaker,Khan takes oath as lawmaker,Khan takes oath as lawmaker,</p>
          </div>
        </div>
        <div class="col-sm-4">
          <img class="img-responsive thumbnail" src="ik3.jpg" alt="">
          <div class="caption">
            <h4><a href="#">Khan takes oath as lawmaker,</a></h4>
            <p>Ex-FIA official has money-laundering evidence against Sharif family: ImranEx-FIA official has money-laundering evidence against Sharif family: Imran.</p>
          </div>
        </div>
        <div class="col-sm-4">
          <img class="img-responsive thumbnail" src="ik1.jpg" alt="">
          <div class="caption">
            <h4><a href="#">Ex-FIA official has money-laundering evidence against Sharif family: Imran</a></h4>
            <p>Imran Khan claims India trying to derail 'reform movement'Imran Khan claims India trying to derail 'reform movement'.</p>
          </div>
        </div>
      </div>
      <!-- /.row -->

      <div class="row margin-b-2">
        <div class="col-sm-4">
          <img class="img-responsive thumbnail" src="ik4.jpg" alt="">
          <div class="caption">
            <h4><a href="#">Ex-FIA official has money-laundering evidence against Sharif family: Imran</a></h4>
            <p>Imran Khan claims India trying to derail 'reform movement'Imran Khan claims India trying to derail 'reform movement'.</p>
          </div>
        </div>
        <div class="col-sm-4">
          <img class="img-responsive thumbnail" src="ik4.jpg" alt="">
          <div class="caption">
            <h4><a href="#">Ex-FIA official has money-laundering evidence against Sharif family: Imran</a></h4>
            <p>Imran Khan claims India trying to derail 'reform movement'Imran Khan claims India trying to derail 'reform movement'.</p>
          </div>
        </div>
        <div class="col-sm-4">
          <img class="img-responsive thumbnail" src="ik4.jpg" alt="">
          <div class="caption">
            <h4><a href="#">Ex-FIA official has money-laundering evidence against Sharif family: Imran</a></h4>
            <p>Imran Khan claims India trying to derail 'reform movement'Imran Khan claims India trying to derail 'reform movement'.</p>
          </div>
        </div>
      </div>
      <!-- /.row -->

      <div class="row margin-b-2">
        <div class="col-sm-4">
          <img class="img-responsive thumbnail" src="ik4.jpg" alt="">
          <div class="caption">
            <h4><a href="#">Ex-FIA official has money-laundering evidence against Sharif family: Imran</a></h4>
            <p>Imran Khan claims India trying to derail 'reform movement'Imran Khan claims India trying to derail 'reform movement'.</p>
          </div>
        </div>
        <div class="col-sm-4">
          <img class="img-responsive thumbnail" src="ik4.jpg" alt="">
          <div class="caption">
            <h4><a href="#">Ex-FIA official has money-laundering evidence against Sharif family: Imran</a></h4>
            <p>Imran Khan claims India trying to derail 'reform movement'Imran Khan claims India trying to derail 'reform movement'.</p>
          </div>
        </div>
        <div class="col-sm-4">
          <img class="img-responsive thumbnail" src="ik4.jpg" alt="">
          <div class="caption">
            <h4><a href="#">Ex-FIA official has money-laundering evidence against Sharif family: Imran</a></h4>
            <p>Imran Khan claims India trying to derail 'reform movement'Imran Khan claims India trying to derail 'reform movement'.</p>
          </div>
        </div>



      </div>
      <?php
include('f.html'); 
?>
   
        </div>
</div>


</div>

  </div>











</body>
</html>



